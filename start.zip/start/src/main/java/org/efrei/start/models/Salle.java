package org.efrei.start.models;

import jakarta.persistence.*;

@Entity
public class Salle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "nom", nullable = false, length = 50)
    private String nom;

    @Column(name = "capacite", nullable = false)
    private int capacite;

    @Column(name = "emplacement", nullable = false, length = 100)
    private String emplacement;

    public Salle(String nom, int capacite, String emplacement) {
        this.nom = nom;
        this.capacite = capacite;
        this.emplacement = emplacement;
    }

    public Salle() {}

    // Getters et setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public String getEmplacement() {
        return emplacement;
    }

    public void setEmplacement(String emplacement) {
        this.emplacement = emplacement;
    }
}
