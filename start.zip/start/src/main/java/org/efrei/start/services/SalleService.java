package org.efrei.start.services;

import org.efrei.start.models.Salle;
import org.efrei.start.repositories.SalleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SalleService {

    private final SalleRepository repository;

    @Autowired
    public SalleService(SalleRepository repository) {
        this.repository = repository;
    }

    public List<Salle> findAll() {
        return repository.findAll();
    }

    public void create(Salle salle) {
        repository.save(salle);
    }

    public Salle findById(int id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteById(int id) {
        repository.deleteById(id);
    }

    public void update(int id, Salle salle) {
        Salle updateSalle = findById(id);
        if (updateSalle != null) {
            updateSalle.setNom(salle.getNom());
            updateSalle.setCapacite(salle.getCapacite());
            updateSalle.setEmplacement(salle.getEmplacement());
            repository.save(updateSalle);
        }
    }
}
