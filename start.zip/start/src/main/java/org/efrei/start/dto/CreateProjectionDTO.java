package org.efrei.start.dto;

import java.time.LocalDateTime;

public class CreateProjectionDTO {
    private String filmId;
    private int salleId;
    private LocalDateTime dateProjection;

    public String getFilmId() {
        return filmId;
    }

    public void setFilmId(String filmId) {
        this.filmId = filmId;
    }

    public int getSalleId() {
        return salleId;
    }

    public void setSalleId(int salleId) {
        this.salleId = salleId;
    }

    public LocalDateTime getDateProjection() {
        return dateProjection;
    }

    public void setDateProjection(LocalDateTime dateProjection) {
        this.dateProjection = dateProjection;
    }
}
