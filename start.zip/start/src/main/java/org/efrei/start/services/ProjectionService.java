package org.efrei.start.services;

import org.efrei.start.dto.CreateProjectionDTO;
import org.efrei.start.models.Projection;
import org.efrei.start.models.Film;
import org.efrei.start.models.Salle;
import org.efrei.start.repositories.ProjectionRepository;
import org.efrei.start.repositories.FilmRepository;
import org.efrei.start.repositories.SalleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProjectionService {

    private final ProjectionRepository projectionRepository;
    private final FilmRepository filmRepository;
    private final SalleRepository salleRepository;

    @Autowired
    public ProjectionService(ProjectionRepository projectionRepository,
                             FilmRepository filmRepository,
                             SalleRepository salleRepository) {
        this.projectionRepository = projectionRepository;
        this.filmRepository = filmRepository;
        this.salleRepository = salleRepository;
    }

    public void create(CreateProjectionDTO projectionDTO) {
        Film film = filmRepository.findById(projectionDTO.getFilmId()).orElseThrow();
        Salle salle = salleRepository.findById(projectionDTO.getSalleId()).orElseThrow();
        Projection projection = new Projection(film, salle, projectionDTO.getDateProjection());
        projectionRepository.save(projection);
    }

    public List <Projection> findAll() {
        return projectionRepository.findAll();
    }

    public Projection findById(Long id) {
        return projectionRepository.findById(id).orElse(null);
    }

    public void deleteById(Long id) {
        projectionRepository.deleteById(id);
    }

    public void update(Long id, Projection projection) {
        Projection existingProjection = findById(id);
        if (existingProjection != null) {
            existingProjection.setFilm(projection.getFilm());
            existingProjection.setSalle(projection.getSalle());
            existingProjection.setDateProjection(projection.getDateProjection());
            projectionRepository.save(existingProjection);
        }
    }
}
