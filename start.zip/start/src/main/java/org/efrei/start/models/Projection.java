package org.efrei.start.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Projection {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "film_id", nullable = false)
    private Film film;

    @ManyToOne
    @JoinColumn(name = "salle_id", nullable = false)
    private Salle salle;

    @Column(name = "date_projection", nullable = false)
    private LocalDateTime dateProjection;

    public Projection() {
    }

    public Projection(Film film, Salle salle, LocalDateTime dateProjection) {
        this.film = film;
        this.salle = salle;
        this.dateProjection = dateProjection;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Film getFilm() {
        return film;
    }

    public void setFilm(Film film) {
        this.film = film;
    }

    public Salle getSalle() {
        return salle;
    }

    public void setSalle(Salle salle) {
        this.salle = salle;
    }

    public LocalDateTime getDateProjection() {
        return dateProjection;
    }

    public void setDateProjection(LocalDateTime dateProjection) {
        this.dateProjection = dateProjection;
    }
}
