package org.efrei.start.controllers;

import org.efrei.start.dto.CreateProjectionDTO;
import org.efrei.start.models.Projection;
import org.efrei.start.services.ProjectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/projections")
public class ProjectionController {

    private final ProjectionService service;

    @Autowired
    public ProjectionController(ProjectionService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<Projection>> findAll() {
        return new ResponseEntity<>(service.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Projection> findById(@PathVariable Long id) {
        Projection projection = service.findById(id);
        if (projection == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(projection, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteById(@PathVariable Long id) {
        service.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody CreateProjectionDTO projectionDTO) {
        service.create(projectionDTO);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Projection projection) {
        service.update(id, projection);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
